export class Session {
  player1: number;
  player2: number;
  timer: number;
}
