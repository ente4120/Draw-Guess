export class Game {
  player1: number;
  player2: number;
  word: string;
  draw: string;
}

