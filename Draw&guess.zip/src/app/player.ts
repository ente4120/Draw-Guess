export class Player {
  id: number;
  score: number;
}
